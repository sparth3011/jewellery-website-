import { Helmet, HelmetProvider } from "react-helmet-async";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Gem, Heart, Shield, Users } from "lucide-react";

const values = [
  {
    icon: Gem,
    title: "Craftsmanship",
    description: "Each piece is meticulously handcrafted by skilled artisans with decades of experience in traditional goldsmithing."
  },
  {
    icon: Shield,
    title: "Authenticity",
    description: "100% BIS Hallmarked gold with certified purity. Every piece comes with a guarantee of authenticity."
  },
  {
    icon: Heart,
    title: "Passion",
    description: "We pour our heart into every design, creating jewellery that tells a story and celebrates life's moments."
  },
  {
    icon: Users,
    title: "Trust",
    description: "Building lasting relationships with our customers through transparency, quality, and exceptional service."
  }
];

const About = () => {
  return (
    <HelmetProvider>
      <Helmet>
        <title>About Aurika | Our Story - Handcrafted Gold Jewellery</title>
        <meta
          name="description"
          content="Discover the story behind Aurika. We craft exquisite 14K & 18K gold jewellery for everyday elegance, combining traditional artistry with modern design."
        />
      </Helmet>

      <div className="min-h-screen bg-ivory">
        <Header />
        
        <main className="pt-24">
          {/* Hero Section */}
          <section className="py-16 md:py-24 bg-gradient-to-b from-cream to-ivory">
            <div className="container mx-auto px-4">
              <div className="max-w-3xl mx-auto text-center">
                <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-charcoal mb-6">
                  The Aurika Story
                </h1>
                <p className="text-lg md:text-xl text-warm-gray leading-relaxed">
                  Born from a passion for timeless elegance, Aurika brings you handcrafted 
                  gold jewellery that celebrates the beauty of everyday moments.
                </p>
              </div>
            </div>
          </section>

          {/* Our Journey */}
          <section className="py-16 md:py-20">
            <div className="container mx-auto px-4">
              <div className="grid md:grid-cols-2 gap-12 items-center max-w-5xl mx-auto">
                <div>
                  <h2 className="font-serif text-3xl md:text-4xl text-charcoal mb-6">
                    Our Journey
                  </h2>
                  <div className="space-y-4 text-warm-gray leading-relaxed">
                    <p>
                      Aurika was founded with a simple belief: fine gold jewellery shouldn't be 
                      reserved only for special occasions. We envisioned a brand that brings the 
                      luxury of pure gold into everyday life.
                    </p>
                    <p>
                      Our journey began in the heart of India's jewellery crafting tradition. 
                      We partnered with master artisans who have inherited their skills through 
                      generations, ensuring each piece carries the legacy of exceptional craftsmanship.
                    </p>
                    <p>
                      Today, Aurika stands as a symbol of accessible luxury—offering 14K and 18K 
                      gold pieces that are both beautifully designed and thoughtfully priced for 
                      everyday wear.
                    </p>
                  </div>
                </div>
                <div className="bg-gradient-to-br from-gold/10 to-cream rounded-2xl p-8 md:p-12">
                  <div className="space-y-6">
                    <div className="flex items-center gap-4">
                      <span className="text-5xl font-serif text-gold">500+</span>
                      <span className="text-warm-gray">Happy Customers</span>
                    </div>
                    <div className="flex items-center gap-4">
                      <span className="text-5xl font-serif text-gold">100%</span>
                      <span className="text-warm-gray">BIS Hallmarked</span>
                    </div>
                    <div className="flex items-center gap-4">
                      <span className="text-5xl font-serif text-gold">50+</span>
                      <span className="text-warm-gray">Unique Designs</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* Our Values */}
          <section className="py-16 md:py-20 bg-white">
            <div className="container mx-auto px-4">
              <div className="text-center mb-12">
                <h2 className="font-serif text-3xl md:text-4xl text-charcoal mb-4">
                  What We Stand For
                </h2>
                <p className="text-warm-gray max-w-2xl mx-auto">
                  Our values guide everything we do, from design to delivery
                </p>
              </div>

              <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8 max-w-5xl mx-auto">
                {values.map((value, index) => (
                  <div 
                    key={index}
                    className="text-center p-6 rounded-xl bg-cream/50 hover:bg-cream transition-colors"
                  >
                    <div className="w-14 h-14 bg-gold/10 rounded-full flex items-center justify-center mx-auto mb-4">
                      <value.icon className="w-7 h-7 text-gold" />
                    </div>
                    <h3 className="font-serif text-xl text-charcoal mb-3">
                      {value.title}
                    </h3>
                    <p className="text-sm text-warm-gray">
                      {value.description}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </section>

          {/* The Aurika Promise */}
          <section className="py-16 md:py-20 bg-charcoal text-white">
            <div className="container mx-auto px-4">
              <div className="max-w-3xl mx-auto text-center">
                <h2 className="font-serif text-3xl md:text-4xl mb-6">
                  The Aurika Promise
                </h2>
                <p className="text-lg text-white/80 mb-8 leading-relaxed">
                  Every piece of Aurika jewellery comes with our unwavering commitment to quality, 
                  authenticity, and your complete satisfaction.
                </p>
                <div className="grid sm:grid-cols-3 gap-6 text-left">
                  <div className="bg-white/10 rounded-lg p-5">
                    <h4 className="font-serif text-gold mb-2">Certified Purity</h4>
                    <p className="text-sm text-white/70">
                      BIS Hallmark on every piece with verifiable HUID
                    </p>
                  </div>
                  <div className="bg-white/10 rounded-lg p-5">
                    <h4 className="font-serif text-gold mb-2">Easy Returns</h4>
                    <p className="text-sm text-white/70">
                      7-day hassle-free return policy on all items
                    </p>
                  </div>
                  <div className="bg-white/10 rounded-lg p-5">
                    <h4 className="font-serif text-gold mb-2">Secure Delivery</h4>
                    <p className="text-sm text-white/70">
                      Insured shipping across India with tracking
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* CTA */}
          <section className="py-16 md:py-20">
            <div className="container mx-auto px-4 text-center">
              <h2 className="font-serif text-3xl md:text-4xl text-charcoal mb-4">
                Ready to Find Your Perfect Piece?
              </h2>
              <p className="text-warm-gray mb-8 max-w-xl mx-auto">
                Explore our collection or get in touch to create something uniquely yours
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <a
                  href="/shop"
                  className="inline-flex items-center justify-center px-8 py-3 bg-gold text-white font-medium rounded-lg hover:bg-gold/90 transition-colors"
                >
                  View Collection
                </a>
                <a
                  href="https://wa.me/919876543210?text=Hi, I'd like to know more about Aurika"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center px-8 py-3 border-2 border-gold text-gold font-medium rounded-lg hover:bg-gold/10 transition-colors"
                >
                  Chat With Us
                </a>
              </div>
            </div>
          </section>
        </main>

        <Footer />
      </div>
    </HelmetProvider>
  );
};

export default About;
