import { Helmet, HelmetProvider } from "react-helmet-async";
import { useParams, useNavigate, Link } from "react-router-dom";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MessageCircle, ArrowLeft, Check, Truck, Shield, RotateCcw } from "lucide-react";
import { getProductById, products, Product } from "@/data/products";

const ProductDetail = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  
  const product = id ? getProductById(parseInt(id)) : undefined;

  if (!product) {
    return (
      <HelmetProvider>
        <div className="min-h-screen bg-ivory">
          <Header />
          <main className="pt-24 pb-16">
            <div className="container mx-auto px-4 text-center">
              <h1 className="font-serif text-3xl text-charcoal mb-4">Product Not Found</h1>
              <p className="text-warm-gray mb-8">The product you're looking for doesn't exist.</p>
              <Button variant="gold" onClick={() => navigate("/shop")}>
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Shop
              </Button>
            </div>
          </main>
          <Footer />
        </div>
      </HelmetProvider>
    );
  }

  const handleEnquiry = () => {
    const message = `Hi, I'm interested in the ${product.name} (${product.karat}, ${product.weight}, ${product.price}). Can you share more details?`;
    window.open(`https://wa.me/919876543210?text=${encodeURIComponent(message)}`, '_blank');
  };

  // Get related products (same category, different id)
  const relatedProducts = products
    .filter((p) => p.category === product.category && p.id !== product.id)
    .slice(0, 4);

  return (
    <HelmetProvider>
      <Helmet>
        <title>{product.name} | Aurika Jewellery</title>
        <meta
          name="description"
          content={`${product.name} - ${product.description}. ${product.karat} ${product.metal}, ${product.weight}. Price: ${product.price}`}
        />
      </Helmet>

      <div className="min-h-screen bg-ivory">
        <Header />
        
        <main className="pt-24 pb-16">
          <div className="container mx-auto px-4">
            {/* Breadcrumb */}
            <nav className="mb-8 text-sm">
              <ol className="flex items-center gap-2 text-warm-gray">
                <li><Link to="/" className="hover:text-gold transition-colors">Home</Link></li>
                <li>/</li>
                <li><Link to="/shop" className="hover:text-gold transition-colors">Shop</Link></li>
                <li>/</li>
                <li><Link to={`/shop?category=${product.category}`} className="hover:text-gold transition-colors">{product.category}</Link></li>
                <li>/</li>
                <li className="text-charcoal">{product.name}</li>
              </ol>
            </nav>

            {/* Product Details */}
            <div className="grid lg:grid-cols-2 gap-12 mb-16">
              {/* Product Image */}
              <div className="relative">
                <div className="aspect-square rounded-2xl overflow-hidden bg-white border border-gold/10 shadow-lg group">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  {product.isNew && (
                    <Badge className="absolute top-4 left-4 bg-gold text-white text-sm px-3 py-1">
                      New Arrival
                    </Badge>
                  )}
                </div>
              </div>

              {/* Product Info */}
              <div className="flex flex-col">
                <div className="mb-6">
                  <div className="flex items-center gap-2 mb-2">
                    <Badge className={product.metal === "Silver" ? "bg-gray-200 text-gray-700" : "bg-gold/10 text-gold"}>
                      {product.karat}
                    </Badge>
                    <Badge variant="outline" className="text-charcoal border-charcoal/20">
                      {product.metal}
                    </Badge>
                    <Badge variant="outline" className="text-charcoal border-charcoal/20">
                      {product.category}
                    </Badge>
                  </div>
                  
                  <h1 className="font-serif text-3xl md:text-4xl text-charcoal mb-4">
                    {product.name}
                  </h1>
                  
                  <p className={`font-serif text-4xl font-semibold mb-6 ${product.metal === "Silver" ? "text-gray-600" : "text-gold"}`}>
                    {product.price}
                  </p>
                  
                  <p className="text-warm-gray text-lg leading-relaxed mb-6">
                    {product.description}
                  </p>
                </div>

                {/* Product Specs */}
                <div className="bg-white rounded-xl p-6 border border-gold/10 mb-6">
                  <h3 className="font-serif text-lg text-charcoal mb-4">Product Details</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-warm-gray">Metal</p>
                      <p className="font-medium text-charcoal">{product.metal}</p>
                    </div>
                    <div>
                      <p className="text-sm text-warm-gray">Purity</p>
                      <p className="font-medium text-charcoal">{product.karat}</p>
                    </div>
                    <div>
                      <p className="text-sm text-warm-gray">Weight</p>
                      <p className="font-medium text-charcoal">{product.weight}</p>
                    </div>
                    <div>
                      <p className="text-sm text-warm-gray">Category</p>
                      <p className="font-medium text-charcoal">{product.category}</p>
                    </div>
                  </div>
                </div>

                {/* Trust Badges */}
                <div className="grid grid-cols-2 gap-3 mb-6">
                  <div className="flex items-center gap-2 text-sm text-charcoal">
                    <Check className="w-5 h-5 text-gold" />
                    <span>BIS Hallmarked</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-charcoal">
                    <Shield className="w-5 h-5 text-gold" />
                    <span>Certificate of Authenticity</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-charcoal">
                    <RotateCcw className="w-5 h-5 text-gold" />
                    <span>7-Day Easy Returns</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-charcoal">
                    <Truck className="w-5 h-5 text-gold" />
                    <span>Free Shipping Pan India</span>
                  </div>
                </div>

                {/* CTA Buttons */}
                <div className="flex flex-col sm:flex-row gap-4 mt-auto">
                  <Button
                    variant="gold"
                    size="lg"
                    className="flex-1 gap-2"
                    onClick={handleEnquiry}
                  >
                    <MessageCircle className="w-5 h-5" />
                    Enquire on WhatsApp
                  </Button>
                  <Button
                    variant="outline"
                    size="lg"
                    className="border-gold text-gold hover:bg-gold hover:text-white"
                    onClick={() => navigate("/shop")}
                  >
                    <ArrowLeft className="w-5 h-5 mr-2" />
                    Back to Shop
                  </Button>
                </div>
              </div>
            </div>

            {/* Related Products */}
            {relatedProducts.length > 0 && (
              <section>
                <h2 className="font-serif text-2xl text-charcoal mb-8 text-center">
                  You May Also Like
                </h2>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                  {relatedProducts.map((relatedProduct) => (
                    <Link
                      key={relatedProduct.id}
                      to={`/product/${relatedProduct.id}`}
                      className="bg-white rounded-xl overflow-hidden border border-gold/10 hover:shadow-xl transition-all duration-300 group"
                    >
                      <div className="relative aspect-square overflow-hidden">
                        <img
                          src={relatedProduct.image}
                          alt={relatedProduct.name}
                          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                        />
                        {relatedProduct.isNew && (
                          <Badge className="absolute top-3 left-3 bg-gold text-white">
                            New
                          </Badge>
                        )}
                      </div>
                      <div className="p-4">
                        <h3 className="font-serif text-sm text-charcoal mb-1 line-clamp-1">
                          {relatedProduct.name}
                        </h3>
                        <p className={`font-serif font-semibold ${relatedProduct.metal === "Silver" ? "text-gray-600" : "text-gold"}`}>
                          {relatedProduct.price}
                        </p>
                      </div>
                    </Link>
                  ))}
                </div>
              </section>
            )}
          </div>
        </main>

        <Footer />
      </div>
    </HelmetProvider>
  );
};

export default ProductDetail;
