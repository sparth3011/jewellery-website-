import { Helmet, HelmetProvider } from "react-helmet-async";
import Header from "@/components/Header";
import HeroSection from "@/components/HeroSection";
import FeaturedCollection from "@/components/FeaturedCollection";
import WhyAurika from "@/components/WhyAurika";
import GallerySection from "@/components/GallerySection";
import TestimonialsSection from "@/components/TestimonialsSection";
import TrustSection from "@/components/TrustSection";
import ContactSection from "@/components/ContactSection";
import FAQSection from "@/components/FAQSection";
import Footer from "@/components/Footer";

const Index = () => {
  return (
    <HelmetProvider>
      <Helmet>
        <title>Aurika - Premium 14K & 18K Gold Jewellery | Everyday Elegance</title>
        <meta
          name="description"
          content="Discover handcrafted 14K & 18K gold pendants, earrings, and everyday jewellery from Aurika. Hallmarked gold pieces perfect for gifting and daily wear. Shop via WhatsApp."
        />
        <meta
          name="keywords"
          content="gold jewellery, 14K gold, 18K gold, gold pendants, gold earrings, Indian jewellery, hallmarked gold, Aurika"
        />
        <meta property="og:title" content="Aurika - Premium Gold Jewellery" />
        <meta
          property="og:description"
          content="Crafted in 14K & 18K Gold. Everyday Elegance. Shop handcrafted gold jewellery via WhatsApp."
        />
        <meta property="og:type" content="website" />
        <link rel="canonical" href="https://aurika.in" />
      </Helmet>

      <div className="min-h-screen">
        <Header />
        <main>
          <HeroSection />
          <FeaturedCollection />
          <GallerySection />
          <WhyAurika />
          <TestimonialsSection />
          <FAQSection />
          <TrustSection />
          <ContactSection />
        </main>
        <Footer />
      </div>
    </HelmetProvider>
  );
};

export default Index;
