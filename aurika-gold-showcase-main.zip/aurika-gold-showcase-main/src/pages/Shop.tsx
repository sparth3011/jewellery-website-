import { Helmet, HelmetProvider } from "react-helmet-async";
import { useState } from "react";
import { Link } from "react-router-dom";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MessageCircle, Filter, X, ArrowUpDown } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { products } from "@/data/products";

const categories = ["All", "Pendants", "Earrings", "Rings", "Chains", "Bangles", "Mangalsutra"];
const karatOptions = ["All", "14K", "18K", "925 Silver"];
const metalOptions = ["All", "Gold", "Silver"];

type SortOption = "default" | "price-low" | "price-high" | "newest" | "weight-low" | "weight-high";

const parsePrice = (price: string): number => {
  return parseInt(price.replace(/[₹,]/g, ""));
};

const parseWeight = (weight: string): number => {
  return parseFloat(weight.replace("g", ""));
};

const Shop = () => {
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [selectedKarat, setSelectedKarat] = useState("All");
  const [selectedMetal, setSelectedMetal] = useState("All");
  const [showFilters, setShowFilters] = useState(false);
  const [sortOption, setSortOption] = useState<SortOption>("default");

  const filteredProducts = products
    .filter((product) => {
      const categoryMatch = selectedCategory === "All" || product.category === selectedCategory;
      const karatMatch = selectedKarat === "All" || product.karat === selectedKarat;
      const metalMatch = selectedMetal === "All" || product.metal === selectedMetal;
      return categoryMatch && karatMatch && metalMatch;
    })
    .sort((a, b) => {
      switch (sortOption) {
        case "price-low":
          return parsePrice(a.price) - parsePrice(b.price);
        case "price-high":
          return parsePrice(b.price) - parsePrice(a.price);
        case "newest":
          return (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0);
        case "weight-low":
          return parseWeight(a.weight) - parseWeight(b.weight);
        case "weight-high":
          return parseWeight(b.weight) - parseWeight(a.weight);
        default:
          return 0;
      }
    });

  const handleEnquiry = (productName: string) => {
    const message = `Hi, I'm interested in the ${productName}. Can you share more details?`;
    window.open(`https://wa.me/919876543210?text=${encodeURIComponent(message)}`, '_blank');
  };

  return (
    <HelmetProvider>
      <Helmet>
        <title>Shop Gold & Silver Jewellery | Aurika - Pendants, Earrings, Rings, Mangalsutra</title>
        <meta
          name="description"
          content="Browse our collection of handcrafted 14K, 18K gold & 925 silver jewellery. Pendants, earrings, rings, mangalsutra and more. Shop via WhatsApp."
        />
      </Helmet>

      <div className="min-h-screen bg-ivory">
        <Header />
        
        <main className="pt-24 pb-16">
          <div className="container mx-auto px-4">
            {/* Hero Section */}
            <div className="text-center mb-8">
              <h1 className="font-serif text-4xl md:text-5xl text-charcoal mb-4">
                Our Collection
              </h1>
              <p className="text-warm-gray max-w-2xl mx-auto">
                Explore handcrafted gold & silver jewellery designed for everyday elegance
              </p>
            </div>

            {/* Filters and Sorting */}
            <div className="mb-8">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-4">
                  <button
                    onClick={() => setShowFilters(!showFilters)}
                    className="md:hidden flex items-center gap-2 text-charcoal"
                  >
                    <Filter className="w-5 h-5" />
                    Filters
                  </button>
                  
                  {/* Sort Dropdown */}
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="outline" className="flex items-center gap-2 border-gold/30 hover:border-gold">
                        <ArrowUpDown className="w-4 h-4" />
                        Sort
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="start" className="bg-white">
                      <DropdownMenuItem 
                        onClick={() => setSortOption("default")}
                        className={sortOption === "default" ? "bg-gold/10" : ""}
                      >
                        Default
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        onClick={() => setSortOption("price-low")}
                        className={sortOption === "price-low" ? "bg-gold/10" : ""}
                      >
                        Price: Low to High
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        onClick={() => setSortOption("price-high")}
                        className={sortOption === "price-high" ? "bg-gold/10" : ""}
                      >
                        Price: High to Low
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        onClick={() => setSortOption("newest")}
                        className={sortOption === "newest" ? "bg-gold/10" : ""}
                      >
                        Newest First
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        onClick={() => setSortOption("weight-low")}
                        className={sortOption === "weight-low" ? "bg-gold/10" : ""}
                      >
                        Weight: Light to Heavy
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        onClick={() => setSortOption("weight-high")}
                        className={sortOption === "weight-high" ? "bg-gold/10" : ""}
                      >
                        Weight: Heavy to Light
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
                <p className="text-warm-gray text-sm">
                  {filteredProducts.length} products
                </p>
              </div>

              <div className={`${showFilters ? 'block' : 'hidden'} md:block space-y-4 md:space-y-0 md:flex md:flex-wrap md:items-center md:gap-8`}>
                {/* Metal Filter */}
                <div>
                  <span className="text-sm text-warm-gray mb-2 block md:inline md:mr-3">Metal:</span>
                  <div className="flex gap-2">
                    {metalOptions.map((metal) => (
                      <button
                        key={metal}
                        onClick={() => setSelectedMetal(metal)}
                        className={`px-4 py-2 rounded-full text-sm transition-colors ${
                          selectedMetal === metal
                            ? "bg-gold text-white"
                            : "bg-white border border-gold/30 text-charcoal hover:border-gold"
                        }`}
                      >
                        {metal}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Category Filter */}
                <div>
                  <span className="text-sm text-warm-gray mb-2 block md:inline md:mr-3">Category:</span>
                  <div className="flex flex-wrap gap-2">
                    {categories.map((category) => (
                      <button
                        key={category}
                        onClick={() => setSelectedCategory(category)}
                        className={`px-4 py-2 rounded-full text-sm transition-colors ${
                          selectedCategory === category
                            ? "bg-gold text-white"
                            : "bg-white border border-gold/30 text-charcoal hover:border-gold"
                        }`}
                      >
                        {category}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Karat Filter */}
                <div>
                  <span className="text-sm text-warm-gray mb-2 block md:inline md:mr-3">Purity:</span>
                  <div className="flex gap-2">
                    {karatOptions.map((karat) => (
                      <button
                        key={karat}
                        onClick={() => setSelectedKarat(karat)}
                        className={`px-4 py-2 rounded-full text-sm transition-colors ${
                          selectedKarat === karat
                            ? "bg-gold text-white"
                            : "bg-white border border-gold/30 text-charcoal hover:border-gold"
                        }`}
                      >
                        {karat}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Clear Filters */}
                {(selectedCategory !== "All" || selectedKarat !== "All" || selectedMetal !== "All") && (
                  <button
                    onClick={() => {
                      setSelectedCategory("All");
                      setSelectedKarat("All");
                      setSelectedMetal("All");
                    }}
                    className="flex items-center gap-1 text-sm text-warm-gray hover:text-charcoal"
                  >
                    <X className="w-4 h-4" />
                    Clear all
                  </button>
                )}
              </div>
            </div>

            {/* Products Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredProducts.map((product) => (
                <Link
                  key={product.id}
                  to={`/product/${product.id}`}
                  className="bg-white rounded-xl overflow-hidden border border-gold/10 hover:shadow-xl transition-all duration-300 group"
                >
                  <div className="relative aspect-square overflow-hidden">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-110"
                    />
                    {product.isNew && (
                      <Badge className="absolute top-3 left-3 bg-gold text-white">
                        New
                      </Badge>
                    )}
                    <Badge className={`absolute top-3 right-3 border-0 ${product.metal === "Silver" ? "bg-gray-200 text-gray-700" : "bg-white/90 text-charcoal"}`}>
                      {product.karat}
                    </Badge>
                    {product.metal === "Silver" && (
                      <Badge className="absolute bottom-3 left-3 bg-gray-500 text-white">
                        Silver
                      </Badge>
                    )}
                  </div>

                  <div className="p-4">
                    <h3 className="font-serif text-lg text-charcoal mb-1">
                      {product.name}
                    </h3>
                    <p className="text-sm text-warm-gray mb-1">
                      {product.category} • {product.weight}
                    </p>
                    <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
                      {product.description}
                    </p>
                    <p className={`font-serif text-xl font-semibold mb-4 ${product.metal === "Silver" ? "text-gray-600" : "text-gold"}`}>
                      {product.price}
                    </p>
                    <Button
                      variant="gold"
                      className="w-full gap-2"
                      onClick={(e) => {
                        e.preventDefault();
                        handleEnquiry(product.name);
                      }}
                    >
                      <MessageCircle className="w-4 h-4" />
                      Enquire Now
                    </Button>
                  </div>
                </Link>
              ))}
            </div>

            {filteredProducts.length === 0 && (
              <div className="text-center py-16">
                <p className="text-warm-gray text-lg">No products found matching your filters.</p>
                <button
                  onClick={() => {
                    setSelectedCategory("All");
                    setSelectedKarat("All");
                    setSelectedMetal("All");
                  }}
                  className="mt-4 text-gold hover:underline"
                >
                  Clear filters
                </button>
              </div>
            )}
          </div>
        </main>

        <Footer />
      </div>
    </HelmetProvider>
  );
};

export default Shop;
