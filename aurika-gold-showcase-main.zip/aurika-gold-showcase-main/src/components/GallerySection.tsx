import gallery1 from "@/assets/gallery-1.jpg";
import gallery2 from "@/assets/gallery-2.jpg";
import gallery3 from "@/assets/gallery-3.jpg";
import gallery4 from "@/assets/gallery-4.jpg";

const galleryImages = [
  { src: gallery1, alt: "Gold pendants collection" },
  { src: gallery2, alt: "Elegant gold ring" },
  { src: gallery3, alt: "Craftsmanship detail" },
  { src: gallery4, alt: "Gift packaging" },
];

const GallerySection = () => {
  return (
    <section id="gallery" className="py-20 md:py-28 bg-background">
      <div className="container">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-14 space-y-4">
          <p className="text-sm font-medium text-primary tracking-widest uppercase">
            Craftsmanship
          </p>
          <h2 className="font-serif text-3xl md:text-4xl lg:text-5xl font-semibold text-foreground">
            Our Gallery
          </h2>
          <p className="text-muted-foreground">
            A glimpse into the artistry and elegance of Aurika jewellery
          </p>
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
          {galleryImages.map((image, index) => (
            <div
              key={index}
              className={`group relative aspect-square overflow-hidden rounded-lg opacity-0 animate-scale-in stagger-${index + 1}`}
            >
              <img
                src={image.src}
                alt={image.alt}
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-foreground/0 group-hover:bg-foreground/10 transition-colors duration-300" />
            </div>
          ))}
        </div>

        {/* Instagram CTA */}
        <div className="text-center mt-12">
          <a
            href="https://instagram.com/aurika8015"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 text-primary hover:text-gold-dark transition-colors font-medium"
          >
            Follow us on Instagram
            <span className="text-lg">→</span>
          </a>
        </div>
      </div>
    </section>
  );
};

export default GallerySection;
