import { Instagram, MessageCircle } from "lucide-react";

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="py-8 bg-foreground border-t border-background/10">
      <div className="container">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          {/* Logo */}
          <a href="#" className="font-serif text-2xl font-semibold text-background">
            Aurika
          </a>

          {/* Social Links */}
          <div className="flex items-center gap-4">
            <a
              href="https://instagram.com/aurika8015"
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 text-background/60 hover:text-gold-light transition-colors"
              aria-label="Instagram"
            >
              <Instagram className="h-5 w-5" />
            </a>
            <a
              href="https://wa.me/919876543210"
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 text-background/60 hover:text-gold-light transition-colors"
              aria-label="WhatsApp"
            >
              <MessageCircle className="h-5 w-5" />
            </a>
          </div>

          {/* Copyright */}
          <p className="text-sm text-background/50">
            © {currentYear} Aurika. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
