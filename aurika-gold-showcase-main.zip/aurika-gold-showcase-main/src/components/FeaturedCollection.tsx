import ProductCard from "./ProductCard";
import heartPendant from "@/assets/heart-pendant.jpg";
import ganeshPendant from "@/assets/ganesh-pendant.jpg";
import goldEarrings from "@/assets/gold-earrings.jpg";

const products = [
  {
    image: heartPendant,
    title: "Heart Pendant",
    subtitle: "18K Gold with Diamonds",
  },
  {
    image: ganeshPendant,
    title: "Lord Ganesha Pendant",
    subtitle: "14K & 18K Gold",
  },
  {
    image: goldEarrings,
    title: "Minimal Drop Earrings",
    subtitle: "14K Gold Daily Wear",
  },
];

const FeaturedCollection = () => {
  return (
    <section id="collection" className="py-20 md:py-28 bg-background">
      <div className="container">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-14 space-y-4">
          <p className="text-sm font-medium text-primary tracking-widest uppercase">
            Our Collection
          </p>
          <h2 className="font-serif text-3xl md:text-4xl lg:text-5xl font-semibold text-foreground">
            Featured Pieces
          </h2>
          <p className="text-muted-foreground">
            Each piece is crafted with precision and care, designed to be cherished 
            for everyday grace and special moments.
          </p>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
          {products.map((product, index) => (
            <ProductCard
              key={product.title}
              {...product}
              delay={`stagger-${index + 1}`}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturedCollection;
