import { MessageCircle } from "lucide-react";
import { Button } from "./ui/button";

interface ProductCardProps {
  image: string;
  title: string;
  subtitle: string;
  delay?: string;
}

const WHATSAPP_NUMBER = "919876543210";

const ProductCard = ({ image, title, subtitle, delay = "" }: ProductCardProps) => {
  const whatsappUrl = `https://wa.me/${WHATSAPP_NUMBER}?text=Hi%20Aurika!%20I'm%20interested%20in%20the%20${encodeURIComponent(title)}.`;

  return (
    <div className={`group opacity-0 animate-fade-in-up ${delay}`}>
      <div className="relative overflow-hidden rounded-lg bg-card shadow-card transition-all duration-500 hover:shadow-hover">
        {/* Image Container */}
        <div className="aspect-[3/4] overflow-hidden">
          <img
            src={image}
            alt={title}
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            loading="lazy"
          />
        </div>

        {/* Content */}
        <div className="p-5 space-y-3">
          <div>
            <h3 className="font-serif text-lg font-medium text-foreground">
              {title}
            </h3>
            <p className="text-sm text-muted-foreground mt-1">
              {subtitle}
            </p>
          </div>

          <Button variant="goldOutline" size="sm" className="w-full" asChild>
            <a href={whatsappUrl} target="_blank" rel="noopener noreferrer">
              <MessageCircle className="h-4 w-4" />
              Enquire Now
            </a>
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;
