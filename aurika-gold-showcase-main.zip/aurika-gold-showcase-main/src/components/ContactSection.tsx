import { MessageCircle, Phone, Instagram, MapPin } from "lucide-react";
import { Button } from "./ui/button";

const WHATSAPP_NUMBER = "919876543210";
const WHATSAPP_URL = `https://wa.me/${WHATSAPP_NUMBER}?text=Hi%20Aurika!%20I'm%20interested%20in%20your%20gold%20jewellery.`;
const PHONE_NUMBER = "+91 98765 43210";

const ContactSection = () => {
  return (
    <section id="contact" className="py-20 md:py-28 bg-foreground text-background">
      <div className="container">
        <div className="max-w-3xl mx-auto text-center space-y-10">
          {/* Header */}
          <div className="space-y-4">
            <p className="text-sm font-medium text-gold-light tracking-widest uppercase">
              Get in Touch
            </p>
            <h2 className="font-serif text-3xl md:text-4xl lg:text-5xl font-semibold">
              Let's Connect
            </h2>
            <p className="text-background/70 text-lg max-w-xl mx-auto">
              Have a question or want to order? Message us on WhatsApp 
              for quick assistance.
            </p>
          </div>

          {/* WhatsApp CTA */}
          <div className="pt-2">
            <Button variant="whatsapp" size="xl" asChild>
              <a href={WHATSAPP_URL} target="_blank" rel="noopener noreferrer">
                <MessageCircle className="h-5 w-5" />
                Message on WhatsApp
              </a>
            </Button>
          </div>

          {/* Contact Info */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-8 border-t border-background/10">
            <a
              href={`tel:${PHONE_NUMBER.replace(/\s/g, "")}`}
              className="flex flex-col items-center gap-3 p-4 hover:bg-background/5 rounded-lg transition-colors"
            >
              <Phone className="h-5 w-5 text-gold-light" />
              <div>
                <p className="text-sm text-background/60">Call Us</p>
                <p className="font-medium">{PHONE_NUMBER}</p>
              </div>
            </a>

            <a
              href="https://instagram.com/aurika8015"
              target="_blank"
              rel="noopener noreferrer"
              className="flex flex-col items-center gap-3 p-4 hover:bg-background/5 rounded-lg transition-colors"
            >
              <Instagram className="h-5 w-5 text-gold-light" />
              <div>
                <p className="text-sm text-background/60">Instagram</p>
                <p className="font-medium">@aurika8015</p>
              </div>
            </a>

            <div className="flex flex-col items-center gap-3 p-4">
              <MapPin className="h-5 w-5 text-gold-light" />
              <div>
                <p className="text-sm text-background/60">Location</p>
                <p className="font-medium">Mumbai, India</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
