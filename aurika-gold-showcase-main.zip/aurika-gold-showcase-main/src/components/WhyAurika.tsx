import { Award, Sparkles, Gift, Heart } from "lucide-react";

const features = [
  {
    icon: Award,
    title: "Hallmarked Gold",
    description: "Certified 14K & 18K pure gold with BIS hallmark guarantee",
  },
  {
    icon: Sparkles,
    title: "Elegant Designs",
    description: "Timeless everyday pieces crafted for modern elegance",
  },
  {
    icon: Gift,
    title: "Perfect for Gifting",
    description: "Beautifully packaged pieces for every special occasion",
  },
  {
    icon: Heart,
    title: "Trusted Brand",
    description: "Loved by customers across India via Instagram",
  },
];

const WhyAurika = () => {
  return (
    <section id="about" className="py-20 md:py-28 bg-secondary/50">
      <div className="container">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-14 space-y-4">
          <p className="text-sm font-medium text-primary tracking-widest uppercase">
            Why Choose Us
          </p>
          <h2 className="font-serif text-3xl md:text-4xl lg:text-5xl font-semibold text-foreground">
            The Aurika Promise
          </h2>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div
              key={feature.title}
              className={`text-center p-6 opacity-0 animate-fade-in-up stagger-${index + 1}`}
            >
              <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-primary/10 text-primary mb-5">
                <feature.icon className="h-6 w-6" />
              </div>
              <h3 className="font-serif text-lg font-medium text-foreground mb-2">
                {feature.title}
              </h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default WhyAurika;
