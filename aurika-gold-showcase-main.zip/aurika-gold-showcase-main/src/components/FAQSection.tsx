import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const faqs = [
  {
    question: "What is the difference between 14K and 18K gold?",
    answer: "14K gold contains 58.3% pure gold mixed with other metals, making it more durable and affordable. 18K gold contains 75% pure gold, offering a richer color and higher purity. Both are excellent choices - 14K for everyday wear and 18K for special pieces."
  },
  {
    question: "How do I know if the gold is genuine?",
    answer: "All our jewellery comes with BIS Hallmark certification, which guarantees the purity of gold. Each piece has a unique HUID (Hallmark Unique Identification) number that can be verified on the BIS website."
  },
  {
    question: "What is your return and exchange policy?",
    answer: "We offer a 7-day return policy for unused items in original condition with all tags attached. Exchanges are available within 15 days. Custom-made pieces are non-returnable but can be exchanged for equal or higher value."
  },
  {
    question: "How should I care for my gold jewellery?",
    answer: "Store each piece separately in a soft cloth pouch. Avoid contact with perfumes, lotions, and chemicals. Clean gently with a soft cloth. Remove jewellery before swimming or bathing. Get professional cleaning once a year."
  },
  {
    question: "Do you offer customization?",
    answer: "Yes! We love creating personalized pieces. Share your design idea or reference image via WhatsApp, and our artisans will craft your dream piece. Custom orders typically take 7-14 days."
  },
  {
    question: "What payment methods do you accept?",
    answer: "We accept UPI, bank transfers, credit/debit cards, and cash on delivery (for select locations). For orders above ₹50,000, we offer easy EMI options through select banks."
  },
  {
    question: "Do you ship across India?",
    answer: "Yes, we ship to all major cities across India with insured delivery. Shipping is free for orders above ₹10,000. Delivery typically takes 3-5 business days."
  },
  {
    question: "What are making charges?",
    answer: "Making charges cover the craftsmanship, design, and labor involved in creating each piece. They typically range from 8-20% depending on the intricacy of the design. We maintain transparent pricing with no hidden costs."
  }
];

const FAQSection = () => {
  return (
    <section id="faq" className="py-16 md:py-24 bg-cream/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="font-serif text-3xl md:text-4xl text-charcoal mb-4">
            Frequently Asked Questions
          </h2>
          <p className="text-warm-gray max-w-2xl mx-auto">
            Everything you need to know about our gold jewellery
          </p>
        </div>

        <div className="max-w-3xl mx-auto">
          <Accordion type="single" collapsible className="space-y-3">
            {faqs.map((faq, index) => (
              <AccordionItem 
                key={index} 
                value={`item-${index}`}
                className="bg-white rounded-lg border border-gold/20 px-6 data-[state=open]:shadow-md transition-shadow"
              >
                <AccordionTrigger className="text-left font-serif text-charcoal hover:text-gold hover:no-underline py-4">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-warm-gray pb-4">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>

        <div className="text-center mt-10">
          <p className="text-warm-gray">
            Still have questions?{" "}
            <a 
              href="https://wa.me/919876543210?text=Hi, I have a question about Aurika jewellery"
              target="_blank"
              rel="noopener noreferrer"
              className="text-gold hover:underline font-medium"
            >
              Chat with us on WhatsApp
            </a>
          </p>
        </div>
      </div>
    </section>
  );
};

export default FAQSection;
