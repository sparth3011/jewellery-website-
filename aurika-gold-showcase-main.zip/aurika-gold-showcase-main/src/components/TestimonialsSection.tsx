import { Star } from "lucide-react";

const testimonials = [
  {
    name: "Priya Sharma",
    location: "Mumbai",
    rating: 5,
    review: "Absolutely stunning piece! The 18K gold pendant I ordered exceeded my expectations. The craftsmanship is impeccable and it arrived beautifully packaged.",
    product: "Heart Pendant"
  },
  {
    name: "Anjali Mehta",
    location: "Delhi",
    rating: 5,
    review: "I've been buying from Aurika for over a year now. Every piece is genuine hallmarked gold and the designs are so elegant. Perfect for daily wear!",
    product: "Gold Earrings"
  },
  {
    name: "Sneha Patel",
    location: "Bangalore",
    rating: 5,
    review: "Gifted the Ganesh pendant to my mother and she absolutely loved it. The quality is premium and the WhatsApp support was very helpful throughout.",
    product: "Ganesh Pendant"
  }
];

const TestimonialsSection = () => {
  return (
    <section className="py-20 md:py-28 bg-background">
      <div className="container">
        <div className="text-center mb-16 opacity-0 animate-fade-in-up">
          <span className="text-sm uppercase tracking-[0.2em] text-primary font-medium">
            Customer Love
          </span>
          <h2 className="font-serif text-3xl md:text-4xl lg:text-5xl font-semibold text-foreground mt-4">
            What Our Customers Say
          </h2>
          <p className="text-muted-foreground mt-4 max-w-xl mx-auto">
            Trusted by hundreds of happy customers across India
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className="bg-secondary/30 rounded-2xl p-8 opacity-0 animate-fade-in-up hover:shadow-luxury transition-shadow duration-300"
              style={{ animationDelay: `${index * 150}ms` }}
            >
              {/* Stars */}
              <div className="flex gap-1 mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star
                    key={i}
                    className="w-5 h-5 fill-primary text-primary"
                  />
                ))}
              </div>

              {/* Review */}
              <p className="text-foreground/80 leading-relaxed mb-6 italic">
                "{testimonial.review}"
              </p>

              {/* Customer Info */}
              <div className="border-t border-border/50 pt-4">
                <p className="font-serif font-semibold text-foreground">
                  {testimonial.name}
                </p>
                <p className="text-sm text-muted-foreground">
                  {testimonial.location} • {testimonial.product}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
