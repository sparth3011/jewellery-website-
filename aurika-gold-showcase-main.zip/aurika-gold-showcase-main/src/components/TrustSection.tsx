const TrustSection = () => {
  return (
    <section className="py-20 md:py-28 bg-secondary/30">
      <div className="container">
        <div className="max-w-3xl mx-auto text-center space-y-6 opacity-0 animate-fade-in-up">
          <div className="inline-block">
            <span className="text-4xl">✨</span>
          </div>
          <blockquote className="font-serif text-2xl md:text-3xl lg:text-4xl font-medium text-foreground leading-relaxed italic">
            "Each Aurika piece is crafted with precision and care, designed to be 
            cherished for everyday grace and special moments."
          </blockquote>
          <p className="text-muted-foreground text-lg">
            — Trusted by hundreds of customers across India
          </p>
        </div>
      </div>
    </section>
  );
};

export default TrustSection;
