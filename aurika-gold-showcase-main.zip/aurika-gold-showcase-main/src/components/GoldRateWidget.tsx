import { TrendingUp, RefreshCw } from "lucide-react";
import { useState } from "react";

const GoldRateWidget = () => {
  const [lastUpdated] = useState(new Date().toLocaleTimeString('en-IN', { 
    hour: '2-digit', 
    minute: '2-digit' 
  }));

  // These rates can be updated manually or connected to a live API
  const goldRates = {
    "24K": 7850,
    "22K": 7190,
    "18K": 5888,
    "14K": 4588,
  };

  return (
    <div className="bg-gradient-to-r from-gold/10 to-cream/50 border border-gold/20 rounded-xl p-4 md:p-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-gold" />
          <h3 className="font-serif text-lg font-semibold text-charcoal">Today's Gold Rate</h3>
        </div>
        <div className="flex items-center gap-1 text-xs text-warm-gray">
          <RefreshCw className="w-3 h-3" />
          <span>Updated: {lastUpdated}</span>
        </div>
      </div>
      
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {Object.entries(goldRates).map(([karat, price]) => (
          <div 
            key={karat} 
            className={`bg-white/80 rounded-lg p-3 text-center border ${
              karat === "14K" || karat === "18K" 
                ? "border-gold shadow-sm" 
                : "border-gold/20"
            }`}
          >
            <span className="text-sm text-warm-gray">{karat} Gold</span>
            <p className="font-serif text-xl font-bold text-charcoal">
              ₹{price.toLocaleString('en-IN')}
            </p>
            <span className="text-xs text-warm-gray">per gram</span>
          </div>
        ))}
      </div>
      
      <p className="text-xs text-warm-gray mt-3 text-center">
        *Rates are indicative. Final price may vary based on design and making charges.
      </p>
    </div>
  );
};

export default GoldRateWidget;
