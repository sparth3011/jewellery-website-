import { MessageCircle } from "lucide-react";
import { Button } from "./ui/button";
import heroBg from "@/assets/hero-bg.jpg";

const WHATSAPP_NUMBER = "919876543210";
const WHATSAPP_URL = `https://wa.me/${WHATSAPP_NUMBER}?text=Hi%20Aurika!%20I'm%20interested%20in%20your%20gold%20jewellery.`;

const HeroSection = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src={heroBg}
          alt="Elegant gold jewellery"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 hero-overlay" />
      </div>

      {/* Content */}
      <div className="relative z-10 container text-center px-6">
        <div className="max-w-3xl mx-auto space-y-8 opacity-0 animate-fade-in-up">
          <h1 className="font-serif text-5xl md:text-7xl lg:text-8xl font-semibold text-cream tracking-tight">
            Aurika
          </h1>
          
          <p className="text-lg md:text-xl lg:text-2xl text-cream/90 font-light tracking-wide">
            Crafted in 14K & 18K Gold ✨ Everyday Elegance
          </p>

          <p className="text-base md:text-lg text-cream/70 max-w-xl mx-auto">
            Discover handcrafted gold pendants, earrings, and everyday jewellery 
            designed to be cherished for moments that matter.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
            <Button variant="hero" size="xl" asChild>
              <a href={WHATSAPP_URL} target="_blank" rel="noopener noreferrer">
                <MessageCircle className="h-5 w-5" />
                Enquire on WhatsApp
              </a>
            </Button>
            <Button variant="goldOutline" size="lg" asChild className="text-cream border-cream/40 hover:bg-cream/10 hover:text-cream">
              <a href="#collection">
                View Collection
              </a>
            </Button>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-cream/40 rounded-full flex items-start justify-center p-2">
          <div className="w-1 h-2 bg-cream/60 rounded-full animate-shimmer" />
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
